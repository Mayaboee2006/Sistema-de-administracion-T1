<?php
// index.php
session_start();

$page = $_GET['page'] ?? 'login';

// Redirección simple según el parámetro 'page'
switch ($page) {
    case 'login':
        require_once __DIR__ . '/frontend/pages/login.php';
        break;
    case 'registro':
        require_once __DIR__ . '/frontend/pages/registro.php';
        break;
    case 'calendario':
        require_once __DIR__ . '/frontend/pages/calendario.php';
        break;
    case 'crear-tarea':
        require_once __DIR__ . '/frontend/pages/crear-tarea.php';
        break;
    case 'crud-tareas':
        require_once __DIR__ . '/frontend/pages/crud-tareas.php';
        break;
    case 'sitio-bienvenida':
        require_once __DIR__ . '/frontend/pages/sitio-bienvenida.php';
        break;
    case 'sitio-ejemplo':
        require_once __DIR__ . '/frontend/pages/sitio-ejemplo.php';
        break;
    case 'sitio-tutorial':
        require_once __DIR__ . '/frontend/pages/sitio-tutorial.php';
        break;
    case 'sitio-soporte':
        require_once __DIR__ . '/frontend/pages/sitio-soporte.php';
        break;
    default:
        require_once __DIR__ . '/frontend/pages/login.php';
        break;
}
?>