// frontend/scripts/script.js

// Función global de redirección para botones requerida por JS
function navegarA(pagina) {
  window.location.href = `index.php?page=${pagina}`;
}

// Lógica para peticiones dinámicas en Forms (Login, Registro, Crear)
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(loginForm);
      const res = await fetch('backend/apis/auth.php?action=login', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(formData)),
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.success) {
        navegarA('calendario');
      } else {
        alert(data.message);
      }
    });
  }

  const registroForm = document.getElementById('registroForm');
  if (registroForm) {
    registroForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(registroForm);
      const res = await fetch('backend/apis/auth.php?action=registro', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(formData)),
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.success) {
        alert("Registro exitoso. Inicia sesión.");
        navegarA('login');
      } else {
        alert(data.message);
      }
    });
  }

  const crearTareaForm = document.getElementById('crearTareaForm');
  if (crearTareaForm) {
    crearTareaForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(crearTareaForm);
      const res = await fetch('backend/apis/products.php?action=crear', {
        method: 'POST',
        body: JSON.stringify(Object.fromEntries(formData)),
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.success) {
        navegarA('crud-tareas');
      } else {
        alert(data.message);
      }
    });
  }
});

async function eliminarTarea(id) {
  if (confirm("¿Desea eliminar la tarea seleccionada?")) {
    const res = await fetch(`backend/apis/products.php?id=${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
      location.reload();
    }
  }
}