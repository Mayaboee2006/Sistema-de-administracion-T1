<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tarea Club - Registro</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
  </header>

  <main class="center-layout">
    <article class="card-form">
      <h2>Crear Cuenta</h2>
      <form id="registroForm">
        <div class="form-group">
          <label>Nombre Completo</label>
          <input type="text" name="nombre_completo" required>
        </div>
        <div class="form-group">
          <label>Correo Electrónico</label>
          <input type="email" name="correo" required>
        </div>
        <div class="form-group">
          <label>Contraseña</label>
          <input type="password" name="contrasena" required>
        </div>
        <button type="submit" class="btn-primary">Registro</button>
      </form>
    </article>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>