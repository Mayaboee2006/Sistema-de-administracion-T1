<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tarea Club - Inicio de Sesión</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
  </header>

  <main class="center-layout">
    <article class="card-form">
      <h2>Ingreso</h2>
      <form id="loginForm">
        <div class="form-group">
          <label>Correo Electrónico</label>
          <input type="email" name="correo" required>
        </div>
        <div class="form-group">
          <label>Contraseña</label>
          <input type="password" name="contrasena" required>
        </div>
        <button type="submit" class="btn-primary">Iniciar Sesión</button>
      </form>
      <br>
      <button onclick="navegarA('registro')" class="btn-secondary" style="width: 100%;">Crear Cuenta</button>
    </article>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>