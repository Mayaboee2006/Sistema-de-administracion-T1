<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Sitio Web - Soporte y Contacto</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
    <nav>
      <ul>
        <li><button onclick="navegarA('sitio-bienvenida')">Bienvenida</button></li>
        <li><button onclick="navegarA('sitio-ejemplo')">Ejemplo Calendario</button></li>
        <li><button onclick="navegarA('sitio-tutorial')">Tutorial</button></li>
        <li><button onclick="navegarA('sitio-soporte')">Soporte</button></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="content">
      <h2>Soporte y Contacto</h2>
      <article>
        <p><strong>Correo electrónico:</strong> soporte@tareaclub.com</p>
        <p><strong>Teléfono:</strong> +52 55 1234 5678</p>
        <p><strong>Ubicación:</strong> Ciudad de México, México</p>
      </article>
    </section>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>