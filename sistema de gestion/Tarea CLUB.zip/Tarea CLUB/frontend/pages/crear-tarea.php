<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tarea Club - Crear Tarea</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
  </header>

  <main class="center-layout">
    <article class="card-form">
      <h2>Crear Tarea</h2>
      <form id="crearTareaForm">
        <div class="form-group">
          <label>Nombre Tarea</label>
          <input type="text" name="titulo" required>
        </div>
        <div class="form-group">
          <label>Fecha</label>
          <input type="date" name="fecha_vencimiento" required>
        </div>
        <div class="form-group">
          <label>Importancia</label>
          <select name="nivel_importancia" required>
            <option value="1" class="imp-1">1 - Verde (Baja)</option>
            <option value="2" class="imp-2">2 - Amarillo (Media)</option>
            <option value="3" class="imp-3">3 - Naranja (Alta)</option>
            <option value="4" class="imp-4">4 - Rojo (Urgente)</option>
          </select>
        </div>
        <div class="form-group">
          <label>Descripción / Observaciones</label>
          <textarea name="descripcion" rows="4"></textarea>
        </div>
        <button type="submit" class="btn-primary">Crear</button>
      </form>
    </article>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>