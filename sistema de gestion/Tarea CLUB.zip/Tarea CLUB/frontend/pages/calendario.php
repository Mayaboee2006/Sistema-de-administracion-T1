<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tarea Club - Calendario</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
    <nav>
      <ul>
        <li><button onclick="navegarA('crear-tarea')">Crear Tarea</button></li>
        <li><button onclick="navegarA('crud-tareas')">CRUD Tareas</button></li>
      </ul>
    </nav>
  </header>

  <main>
    <aside>
      <h3>Acciones</h3>
      <button onclick="navegarA('crear-tarea')" class="btn-secondary">Nueva Tarea</button>
      <button onclick="navegarA('sitio-bienvenida')" class="btn-primary">Ir a Sitio Web</button>
    </aside>

    <section class="content">
      <h2>Calendario de Tareas</h2>
      <div class="calendar-grid">
        <div class="calendar-day">1</div>
        <div class="calendar-day">2</div>
        <div class="calendar-day">3</div>
        <div class="calendar-day">4</div>
        <div class="calendar-day">5</div>
        <div class="calendar-day">6</div>
        <div class="calendar-day">7</div>
      </div>
    </section>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>