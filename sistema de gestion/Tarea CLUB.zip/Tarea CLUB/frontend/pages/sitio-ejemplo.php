<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Sitio Web - Ejemplo de Calendario</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
    <nav>
      <ul>
        <li><button onclick="navegarA('sitio-bienvenida')">Bienvenida</button></li>
        <li><button onclick="navegarA('sitio-ejemplo')">Ejemplo Calendario</button></li>
        <li><button onclick="navegarA('sitio-tutorial')">Tutorial</button></li>
        <li><button onclick="navegarA('sitio-soporte')">Soporte</button></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="content">
      <h2>Ejemplo de cómo se visualiza el calendario</h2>
      <article>
        <p>A continuación se muestra una simulación de la vista interactiva del calendario:</p>
        <br>
        <img src="frontend/img/calendario-demo.png" alt="Ejemplo Calendario" style="width: 100%; max-width: 500px; border-radius: 10px; border: 1px solid var(--silver);">
      </article>
    </section>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>