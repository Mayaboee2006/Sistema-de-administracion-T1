<?php
require_once __DIR__ . '/../../backend/conections/conection.php';
require_once __DIR__ . '/../../backend/services/ProductService.php';

$database = new Database();
$db = $database->getConnection();
$service = new ProductService($db);
$usuario_id = $_SESSION['usuario_id'] ?? 1; // ID de respaldo o sesión activa
$tareas = $service->listarTareas($usuario_id);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Tarea Club - Vista de Tareas (CRUD)</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
    <nav>
      <ul>
        <li><button onclick="navegarA('calendario')">Calendario</button></li>
        <li><button onclick="navegarA('crear-tarea')">Crear Tarea</button></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="content">
      <h2>Vista de Tareas (CRUD)</h2>
      <table class="crud-table">
        <thead>
          <tr>
            <th>Título</th>
            <th>Descripción</th>
            <th>Fecha</th>
            <th>Importancia</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($tareas as $t): ?>
            <tr>
              <td><?= htmlspecialchars($t['titulo']) ?></td>
              <td><?= htmlspecialchars($t['descripcion']) ?></td>
              <td><?= $t['fecha_vencimiento'] ?></td>
              <td>
                <span class="imp-<?= $t['nivel_importancia'] ?>" style="padding: 4px 8px; border-radius: 6px;">
                  Nivel <?= $t['nivel_importancia'] ?>
                </span>
              </td>
              <td>
                <button onclick="eliminarTarea(<?= $t['id'] ?>)" class="btn-danger">Eliminar</button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <br>
      <button onclick="navegarA('crear-tarea')" class="btn-secondary">Ir a crear tarea</button>
    </section>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>