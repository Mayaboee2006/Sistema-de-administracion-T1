<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Sitio Web - Tutorial</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
    <nav>
      <ul>
        <li><button onclick="navegarA('sitio-bienvenida')">Bienvenida</button></li>
        <li><button onclick="navegarA('sitio-ejemplo')">Ejemplo Calendario</button></li>
        <li><button onclick="navegarA('sitio-tutorial')">Tutorial</button></li>
        <li><button onclick="navegarA('sitio-soporte')">Soporte</button></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="content">
      <h2>Tutorial de creación de tareas</h2>
      <article>
        <h3>Pasos para crear una tarea:</h3>
        <ol style="margin-left: 20px; margin-top: 10px;">
          <li>Inicia sesión con tus credenciales.</li>
          <li>Haz clic en el botón <strong>Crear Tarea</strong>.</li>
          <li>Completa los datos del formulario y asigna el color según su prioridad.</li>
          <li>Guarda la tarea para visualizarla en tu calendario y CRUD.</li>
        </ol>
      </article>
    </section>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>