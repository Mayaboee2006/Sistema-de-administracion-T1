<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Sitio Web - Bienvenida</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Black+Ops+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="frontend/styles/style.css">
</head>
<body>
  <header>
    <h1>Tarea Club</h1>
    <nav>
      <ul>
        <li><button onclick="navegarA('sitio-bienvenida')">Bienvenida</button></li>
        <li><button onclick="navegarA('sitio-ejemplo')">Ejemplo Calendario</button></li>
        <li><button onclick="navegarA('sitio-tutorial')">Tutorial</button></li>
        <li><button onclick="navegarA('sitio-soporte')">Soporte</button></li>
        <li><button onclick="navegarA('login')">Ir a App</button></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="content">
      <h2>Bienvenida</h2>
      <article>
        <h3>Propósito de la aplicación</h3>
        <p>Tarea Club es una plataforma diseñada para facilitar el seguimiento de proyectos personales y profesionales mediante un sistema dinámico de organización por fechas y niveles de importancia.</p>
        <br>
        <img src="frontend/img/logo.png" alt="Logo de Tarea Club" style="max-width: 200px; border-radius: 10px;">
      </article>
    </section>
  </main>

  <footer>
    <p>Políticas, Legales, Redes Sociales y Copyright - Tarea Club</p>
  </footer>
  <script src="frontend/scripts/script.js"></script>
</body>
</html>