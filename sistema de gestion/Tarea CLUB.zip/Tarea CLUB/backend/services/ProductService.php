<?php
// backend/services/ProductService.php
require_once __DIR__ . '/../models/Product.php';

class ProductService {
    private $productModel;

    public function __construct($db) {
        $this->productModel = new Product($db);
    }

    public function listarTareas($usuario_id) {
        $this->productModel->usuario_id = $usuario_id;
        return $this->productModel->obtenerPorUsuario();
    }

    public function crearTarea($usuario_id, $datos) {
        if (empty($datos['titulo']) || empty($datos['fecha_vencimiento']) || empty($datos['nivel_importancia'])) {
            return ["success" => false, "message" => "Faltan campos obligatorios."];
        }

        $this->productModel->usuario_id = $usuario_id;
        $this->productModel->titulo = $datos['titulo'];
        $this->productModel->descripcion = $datos['descripcion'] ?? '';
        $this->productModel->fecha_vencimiento = $datos['fecha_vencimiento'];
        $this->productModel->nivel_importancia = $datos['nivel_importancia'];

        if ($this->productModel->crear()) {
            return ["success" => true, "message" => "Tarea creada con éxito."];
        }
        return ["success" => false, "message" => "Error al guardar la tarea."];
    }

    public function actualizarTarea($usuario_id, $datos) {
        if (empty($datos['id']) || empty($datos['titulo'])) {
            return ["success" => false, "message" => "ID y título son obligatorios."];
        }

        $this->productModel->id = $datos['id'];
        $this->productModel->usuario_id = $usuario_id;
        $this->productModel->titulo = $datos['titulo'];
        $this->productModel->descripcion = $datos['descripcion'] ?? '';
        $this->productModel->fecha_vencimiento = $datos['fecha_vencimiento'];
        $this->productModel->nivel_importancia = $datos['nivel_importancia'];
        $this->productModel->estado = $datos['estado'] ?? 'pendiente';

        if ($this->productModel->actualizar()) {
            return ["success" => true, "message" => "Tarea actualizada con éxito."];
        }
        return ["success" => false, "message" => "Error al actualizar la tarea."];
    }

    public function eliminarTarea($usuario_id, $id) {
        $this->productModel->id = $id;
        $this->productModel->usuario_id = $usuario_id;

        if ($this->productModel->eliminar()) {
            return ["success" => true, "message" => "Tarea eliminada con éxito."];
        }
        return ["success" => false, "message" => "Error al eliminar la tarea."];
    }
}
?>