<?php
// backend/models/Product.php

class Product {
    private $conn;
    private $table_name = "tareas";

    public $id;
    public $usuario_id;
    public $titulo;
    public $descripcion;
    public $fecha_vencimiento;
    public $nivel_importancia;
    public $estado;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Obtener todas las tareas de un usuario
    public function obtenerPorUsuario() {
        $query = "SELECT * FROM " . $this->table_name . " WHERE usuario_id = :usuario_id ORDER BY fecha_vencimiento ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":usuario_id", $this->usuario_id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // Crear tarea
    public function crear() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (usuario_id, titulo, descripcion, fecha_vencimiento, nivel_importancia) 
                  VALUES (:usuario_id, :titulo, :descripcion, :fecha_vencimiento, :nivel_importancia)";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":usuario_id", $this->usuario_id);
        $stmt->bindParam(":titulo", htmlspecialchars(strip_tags($this->titulo)));
        $stmt->bindParam(":descripcion", htmlspecialchars(strip_tags($this->descripcion)));
        $stmt->bindParam(":fecha_vencimiento", $this->fecha_vencimiento);
        $stmt->bindParam(":nivel_importancia", $this->nivel_importancia);

        return $stmt->execute();
    }

    // Actualizar tarea
    public function actualizar() {
        $query = "UPDATE " . $this->table_name . " 
                  SET titulo = :titulo, descripcion = :descripcion, 
                      fecha_vencimiento = :fecha_vencimiento, nivel_importancia = :nivel_importancia, estado = :estado 
                  WHERE id = :id AND usuario_id = :usuario_id";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":usuario_id", $this->usuario_id);
        $stmt->bindParam(":titulo", htmlspecialchars(strip_tags($this->titulo)));
        $stmt->bindParam(":descripcion", htmlspecialchars(strip_tags($this->descripcion)));
        $stmt->bindParam(":fecha_vencimiento", $this->fecha_vencimiento);
        $stmt->bindParam(":nivel_importancia", $this->nivel_importancia);
        $stmt->bindParam(":estado", $this->estado);

        return $stmt->execute();
    }

    // Eliminar tarea
    public function eliminar() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id AND usuario_id = :usuario_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":usuario_id", $this->usuario_id);

        return $stmt->execute();
    }
}
?>