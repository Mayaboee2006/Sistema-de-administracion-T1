<?php
// backend/controllers/ProductController.php
session_start();
require_once __DIR__ . '/../conections/conection.php';
require_once __DIR__ . '/../services/ProductService.php';

class ProductController {
    private $service;

    public function __construct() {
        $database = new Database();
        $db = $database->getConnection();
        $this->service = new ProductService($db);
    }

    private function verificarSesion() {
        if (!isset($_SESSION['usuario_id'])) {
            http_response_code(401);
            echo json_encode(["success" => false, "message" => "No has iniciado sesión."]);
            exit;
        }
    }

    public function manejarPeticion() {
        $method = $_SERVER['REQUEST_METHOD'];
        $action = $_GET['action'] ?? '';

        $this->verificarSesion();
        $usuario_id = $_SESSION['usuario_id'];

        header('Content-Type: application/json');

        switch ($method) {
            case 'GET':
                echo json_encode($this->service->listarTareas($usuario_id));
                break;

            case 'POST':
                $datos = json_decode(file_get_contents("php://input"), true) ?? $_POST;
                if ($action === 'crear') {
                    echo json_encode($this->service->crearTarea($usuario_id, $datos));
                } elseif ($action === 'actualizar') {
                    echo json_encode($this->service->actualizarTarea($usuario_id, $datos));
                }
                break;

            case 'DELETE':
                $id = $_GET['id'] ?? null;
                if ($id) {
                    echo json_encode($this->service->eliminarTarea($usuario_id, $id));
                } else {
                    echo json_encode(["success" => false, "message" => "ID no proporcionado."]);
                }
                break;

            default:
                http_response_code(405);
                echo json_encode(["message" => "Método no permitido."]);
                break;
        }
    }
}
?>