<?php
// backend/apis/products.php
require_once __DIR__ . '/../controllers/usercontroller.php';

$controller = new ProductController();
$controller->manejarPeticion();
?>