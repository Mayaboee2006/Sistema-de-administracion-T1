Creación de la base de datos
CREATE DATABASE IF NOT EXISTS tienda_club CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tienda_club;

-- Tabla de Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    correo VARCHAR(150) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de Tareas
CREATE TABLE IF NOT EXISTS tareas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT,
    fecha_vencimiento DATE NOT NULL,
    nivel_importancia ENUM('1', '2', '3', '4') NOT NULL DEFAULT '1', -- 1: Verde, 2: Amarillo, 3: Naranja, 4: Rojo
    estado ENUM('pendiente', 'completada') NOT NULL DEFAULT 'pendiente',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserción de datos de prueba
INSERT INTO usuarios (nombre_completo, correo, contrasena) VALUES
('Usuario Demo', 'demo@tareaclub.com', '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe1g.N.xK1f6oXJ2yM2hH3S0.1z1g3Y6S'); -- contraseña: password123

INSERT INTO tareas (usuario_id, titulo, descripcion, fecha_vencimiento, nivel_importancia, estado) VALUES
(1, 'Diseñar prototipos', 'Crear wireframes para el proyecto Tarea Club', '2026-10-05', '1', 'pendiente'),
(1, 'Revisar base de datos', 'Validar la estructura de tablas y llaves foráneas', '2026-10-02', '3', 'pendiente'),
(1, 'Entrega de avance', 'Subir los archivos PHP y CSS actualizados', '2026-10-01', '4', 'pendiente');