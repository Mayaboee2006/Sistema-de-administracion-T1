# Tarea Club - Sistema y Sitio Web de Gestión de Tareas

**Tarea Club** es una plataforma web desarrollada con una arquitectura MVC limpia que combina un **Sistema Web interactivo** para la gestión de tareas personales/laborales y un **Sitio Web informativo** que sirve como guía y soporte para los usuarios.

---

## 🛠️ Tecnologías Utilizadas

* **Backend:** PHP (PDO, Programación Orientada a Objetos, Servicios y Controladores)
* **Frontend:** HTML5 semántico (`header`, `footer`, `main`, `section`, `article`, `aside`, `img`), CSS3 moderno y JavaScript vanilla.
* **Base de Datos:** MySQL / MariaDB (`tienda_club`)
* **Fuentes:** [Black Ops One](https://fonts.google.com/specimen/Black+Ops+One) vía Google Fonts.

---

## 🎨 Paleta de Colores (CSS Hex)

* **Celadon (`#afd5aa`):** Verde suave para acentos e indicadores de baja importancia.
* **White Smoke (`#f0f2ef`):** Color de fondo principal.
* **Stone Brown (`#5c5346`):** Encabezados, pie de página y textos principales.
* **Silver (`#a69f98`):** Bordes, botones secundarios y elementos neutros.
* **Smoky Rose (`#8c6057`):** Botones primarios, llamados a la acción y alertas.

---

## 📂 Estructura del Proyecto

```text
proyecto CRUD/
├── backend/
│   ├── apis/
│   │   ├── auth.php
│   │   └── products.php
│   ├── conections/
│   │   └── conection.php
│   ├── controllers/
│   │   └── ProductController.php
│   ├── models/
│   │   ├── Product.php
│   │   └── User.php
│   └── services/
│       └── ProductService.php
├── docs/
│   ├── database.sql
│   └── README.md
├── frontend/
│   ├── img/
│   ├── pages/
│   │   ├── calendario.php
│   │   ├── crear-tarea.php
│   │   ├── crud-tareas.php
│   │   ├── login.php
│   │   ├── registro.php
│   │   ├── sitio-bienvenida.php
│   │   ├── sitio-ejemplo.php
│   │   ├── sitio-soporte.php
│   │   └── sitio-tutorial.php
│   ├── scripts/
│   │   └── script.js
│   └── styles/
│       └── style.css
├── .env.example
├── .gitignore
└── index.php

## Requisitos
- PHP 8.2 o superior (con extensión `pdo_mysql`)
- MySQL o MariaDB

## Instalación y Configuración

1. **Base de Datos**:
   Importar el archivo `docs/database.sql` en MySQL/MariaDB:
   ```bash
   mysql -u root -p < docs/database.sql
   ```

2. **Variables de Entorno**:
   Copiar `.env.example` a `.env` y configurar las credenciales:
   ```ini
   APP_ENV=local
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_NAME=tienda_club
   DB_USER=jonathan_maya
   DB_PASSWORD=123456
   ```

3. **Iniciar Servidor**:
   Desde la raíz de la carpeta `proyecto`:
   ```bash
   php -S localhost:8000
   ```

4. **Acceder a la Aplicación**:
   Abrir en el navegador: [http://localhost:8000](http://localhost:8000)

## Endpoints de la API (`/backend/apis/products.php`)

| Método | URL | Descripción | Código Éxito |
|---|---|---|---|
| `GET` | `/backend/apis/products.php` | Listar todos los productos | 200 OK |
| `GET` | `/backend/apis/products.php?id={id}` | Obtener un producto por ID | 200 OK (o 404) |
| `POST` | `/backend/apis/products.php` | Crear un nuevo producto (JSON en body) | 201 Created |
| `PUT` | `/backend/apis/products.php?id={id}` | Actualizar un producto (JSON en body) | 200 OK (o 404) |
| `DELETE` | `/backend/apis/products.php?id={id}` | Eliminar un producto | 204 No Content (o 404) |
